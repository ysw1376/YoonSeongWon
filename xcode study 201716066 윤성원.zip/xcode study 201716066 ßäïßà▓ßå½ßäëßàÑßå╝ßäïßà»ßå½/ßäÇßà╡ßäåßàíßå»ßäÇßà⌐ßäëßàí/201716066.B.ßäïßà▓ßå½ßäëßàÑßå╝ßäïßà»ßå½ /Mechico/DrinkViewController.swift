//
//  ViewController.swift
//  Drink
//
//  Created by 203a on 2022/06/16.
//

import UIKit

class DrinkViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func btnMoveImgView(_ sender: UIButton) {
        tabBarController?.selectedIndex = 0
    }

}

